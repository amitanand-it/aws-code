import AWS from 'aws-sdk';
import sharp from 'sharp';
import fetch from 'node-fetch';

export const handler = async(event) => {

//	let url = 'https://tiimg.tistatic.com/new_website1/micro_cate_images/2/b/72/31372-w124-h124.jpg';
	let url = 'https://tiimg.tistatic.com/new_website1/micro_cate_images/2/b/72/31372.jpg';

	const response = await fetch(url);
	const imageBuffer = await response.buffer();


	const resizedImageBuffer = await sharp(imageBuffer).resize(124, 124).toBuffer();

	console.log(resizedImageBuffer.toString('base64'));

/*
	return {
		statusCode: 200,
		headers: { 'Content-Type': response.headers.get('Content-Type') },
		body: resizedImageBuffer.toString('base64'),
		isBase64Encoded: true,
	};
*/


	return {
		statusCode: 200,
		headers: { 'Content-Type': response.headers.get('Content-Type') },
		body: resizedImageBuffer.toString('base64'),
		isBase64Encoded: true,
	};

};

handler({});
